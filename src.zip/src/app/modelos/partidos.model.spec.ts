import { Partidos } from './partidos.model';

describe('Partidos', () => {
  it('should create an instance', () => {
    expect(new Partidos()).toBeTruthy();
  });
});
