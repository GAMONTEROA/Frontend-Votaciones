import { Candidatos } from './candidatos.model';

describe('Candidatos', () => {
  it('should create an instance', () => {
    expect(new Candidatos()).toBeTruthy();
  });
});
