export class Candidato {
    _id?:string;
    cedula?:string;
    numresolucion?: string;
    nombre?:string;
    apellido?:string;
}