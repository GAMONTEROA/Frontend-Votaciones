export enum NgxLegendItemColor {
  GREEN = 'green',
  PURPLE = 'purple',
  LIGHT_PURPLE = 'light-purple',
  BLUE = 'blue',
  YELLOW = 'yellow',
}
